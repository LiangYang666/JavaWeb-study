package com.wxy.service.role;

import com.wxy.pojo.Role;

import java.util.List;

/**
 * @author Administrator
 * @Auther: wuxy
 * @Date: 2021/1/28 - 01 - 28 - 20:45
 * @Description: com.wxy.service.role
 * @version: 1.0
 */
public interface RoleService {
    public List<Role> getRoleList();
}
