package com.wxy.util;

/**
 * @author Administrator
 * @Auther: wuxy
 * @Date: 2021/1/27 - 01 - 27 - 15:47
 * @Description: com.wxy.util
 * @version: 1.0
 */
public class Constants {
    public final static String USER_SESSION="userSession";
    public final static String SYS_MESSAGE = "message";
    public final static int pageSize = 5;
}
