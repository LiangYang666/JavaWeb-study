# smbms
B站【遇见狂神说】JavaWeb项目【超市订单管理系统】

项目环境：
IDEA2020.3.1 JDK1.8.0_271 Tomcat9.0.41 MySql5.7.33

项目参考文档：
详见StudyNotes库中05.JavaWeb部分

教学参考：
https://www.bilibili.com/video/BV12J411M7Sj
